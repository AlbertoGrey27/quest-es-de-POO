import java.util.Scanner;

public class App {
    
    /*1 - Soma dos N primeiros números pares
    Escreva um programa em Java que calcule a soma dos N primeiros números pares. O valor de N deve ser fornecido pelo usuário.
    Requisitos:
    O programa deve solicitar ao usuário que insira um número inteiro positivo N.
    O programa deve utilizar um loop para calcular a soma dos N primeiros números pares.
    O resultado da soma deve ser exibido na tela.*/

    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
     System.out.print("Digite um numero inteiro e positivo: ");
        int Num = sc.nextInt();
        sc.close();

        int i=0;
        int j=0;
        int soma=0;

        for(i = 0; i < Num; i++){
            soma = soma + (j + 2);
            j = j + 2;
        }

        System.out.println(soma);

        
        
    }
}
