public class App {
    public static void main(String[] args) throws Exception {
        disciplina di = new disciplina();
        aluno aluno1 = new aluno();
        aluno aluno2 = new aluno();
        aluno aluno3 = new aluno();
        aluno aluno4 = new aluno();
        aluno aluno5 = new aluno();
        aluno aluno6 = new aluno();

        aluno1.nome = "alberto";
        aluno2.nome = "gabriel";
        aluno3.nome = "yago";
        aluno4.nome = "dani";
        aluno5.nome = "davi";
        aluno6.nome = "cadu";

        di.alunos[0] = aluno1;
        di.alunos[1] = aluno2;
        di.alunos[2] = aluno3;
        di.alunos[3] = aluno4;
        di.alunos[4] = aluno5;
        di.alunos[5] = aluno6;
        
        di.darnotas();
        di.imprimir();
    }
}
