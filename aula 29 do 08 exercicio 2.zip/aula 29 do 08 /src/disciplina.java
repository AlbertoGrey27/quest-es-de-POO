public class Disciplina{

    String nome;
    String horario;
    int sala;
    Professor prof = new Professor();
    Aluno[] alunos = new Alunos[6];

    public void vincularProfADisciplina(){
        System.out.println(prof.nome);
    }

    public void darnotas(){
        Scanner sc = new Scanner(System.in);
        int i;
        for (i=0;i<5;i++) {
            System.out.println("insira as notas do aluno"+this.alunos[i].nome);
            System.out.print("Escreva a 1ª nota: ");
            this.aluno[i].nota1 = sc.nextdouble()
            System.out.print("\nEscreva a 2ª nota: ");
            this.aluno[i].nota1 = sc.nextdouble()
            System.out.print("\nEscreva a 3ª nota: ");
            this.aluno[i].nota1 = sc.nextdouble()
            System.out.print("\nEscreva a 4ª nota: ");
            this.aluno[i].nota1 = sc.nextdouble()
        }
    }

    public void imprimir(){
        int i;
        for (i=0;i<5;i++){
            System.out.println("Nome do aluno "+ this.aluno[i].nome
            +"\n1ªnota: "+this.aluno[i].nota1
            +"\n2ªnota: "+this.aluno[i].nota2
            +"\n3ªnota: "+this.aluno[i].nota3
            +"\n4ªnota: "+this.aluno[i].nota4
            +"\nA media do aluno é: "+this.aluno[i].getmedia
            +"\nO aluno foi aprovado?"+this.aluno[i].aprovado());
        }
    }

}