
public class professor{
    String nome;
    String departamento;
    String email;
}
   


