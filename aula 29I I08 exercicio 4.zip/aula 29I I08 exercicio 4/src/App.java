import java.util.Scanner;
public class App {
    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);

        System.out.print("Digite um numero: ");
        int num = sc.nextInt();

        int i;
        for (i = 0 ; num!=1;i++){
            if(num%2==0){
                num = num/2;
            }
            else{
                num = (num*3)+1;
            }
        }
        System.out.println(i);
        
        sc.close();


    }
}
