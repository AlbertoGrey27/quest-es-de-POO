import java.util.Scanner;

public class Livro {

    Scanner sc = new Scanner(System.in);
    int publicação = 2004;
    String titulo = " as aventuras de jorge";
    String genero = "Aventura";
    String autor = "Amanda Lobato";
    double NumeroPaginas = 500;

    public void Ano(){
        this.publicação = sc.nextInt();
    }
    public void titulo(){
        this.titulo = sc.nextLine();
    }
    public void genero(){
        this.genero = sc.nextLine();
    }
    public void autor(){
        this.autor = sc.nextLine();
    }
    public void NumeroPaginas(){
        this.NumeroPaginas = sc.nextInt();
    }

    public void verificarIdade(){
        System.out.print("digite o ano que voce nasceu: ");
        int ano = sc.nextInt();

        if (publicação<ano) {
            System.out.println("voce é mais novo que o livro");
        }
        else if (publicação>ano) {
            System.out.println("voce é mais velho que o livro");
        }
        else {
            System.out.println("voce tem a mesma idade que o livro");
        }
    }

    public void porcentagemLeitura(){
        System.out.print("quantas paginas voce leu: ");
        double lidas = sc.nextDouble();

        double porcentagem = (lidas*100)/NumeroPaginas;

        System.out.print("a porcentagem do livro que voce leu é "+ porcentagem+"%");
    }
}
