public abstract class Intens {
    private String nome;
    private int id;
    private double preco;
    private boolean disponivel=true;

    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public double getPreco() {
        return preco;
    }
    public void setPreco(double preco) {
        this.preco = preco;
    }
    public boolean isDisponivel() {
        return disponivel;
    }
    public void setDisponivel(boolean disponivel) {
        this.disponivel = disponivel;
    }
    public Intens(String nome, int id, boolean disponivel) {
        this.nome = nome;
        this.id = id;
        this.disponivel = disponivel;
    }
    @Override
    public String toString() {
        return "Intens [nome=" + nome + ", id=" + id + ", preco=" + preco + ", disponivel=" + disponivel;
    }

    
    
}
