import java.util.ArrayList;
import java.util.Scanner;

public class Biblioteca {
    private double saldo;
    ArrayList<Intens> catalogo = new ArrayList<>();
    Scanner sc = new Scanner(System.in);

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public Biblioteca(double saldo) {
        this.saldo = saldo;
    }
    
    public void alugar(){
        listarItems();
        System.out.println("Escolha o id do item para alugar: ");
        int Escolha = sc.nextInt();
        if(catalogo.get(Escolha).isDisponivel()==true){
            saldo = saldo + catalogo.get(Escolha).getPreco();
            System.out.println("obrigado por alugar");
            catalogo.get(Escolha).setDisponivel(false);
        }else{
            System.out.println("Esse item já esta alugado");
        }
    }
    public void devolver(){
        listarItems();
        System.out.println("Escolha o id do item para devolver: ");
        int Escolha = sc.nextInt();
        if(catalogo.get(Escolha).isDisponivel()==false){
            System.out.println("obrigado por devolver");
            catalogo.get(Escolha).setDisponivel(true);
        }else{
            System.out.println("Esse item não foi alugado");
        }
    }

    public void listarItems(){
        for (Intens intens : catalogo) {
            System.out.println(intens.toString());
        }
    }

    public void mostrarSaldo(){
        System.out.println("Essa biblioteca tem um saldo de: "+getSaldo()+"R$");
    }
}
