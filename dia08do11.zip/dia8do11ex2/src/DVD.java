public class DVD extends Intens {
    private double duracao;

    public double getDuracao() {
        return duracao;
    }

    public void setDuracao(double duracao) {
        this.duracao = duracao;
    }

    public DVD(String nome, int id,  boolean disponivel, double duracao) {
        super(nome, id, disponivel);
        this.setPreco(10);
        this.duracao = duracao;
    }

    @Override
    public String toString() {
        return super.toString()+", duracao=" + duracao + "]";
    }
    
    
}
