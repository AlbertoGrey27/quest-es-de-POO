public class App {
    public static void main(String[] args) throws Exception {
        /*Daniela é dona de uma biblioteca, e precisa catalogar os seus produtos de forma que permita que ela saiba quais estão
        disponíveis para empréstimo e quais já estão emprestados.
	    Crie uma classe Livro que possui 5 atributos: preço, nome, autor, id e disponível.  Depois, uma classe DVD que possui 5 atributos:
        filme, preço, duração, id e disponível. Crie uma interface itemDaBiblioteca que possua um método emprestar e um método devolver e faça Livro e DVD 
        implementarem ela. Emprestar um DVD custa 10 reais e emprestar um Livro custa 5. O dinheiro é pago na hora do empréstimo e é devolvido no momento que o item
        volta para a biblioteca.
	    Por fim crie uma classe Biblioteca que possui um array de itemDaBiblioteca e um atributo saldo, crie métodos para emprestar e devolver determinado item de 
        acordo com o seu id. Por fim, crie um método que exiba cada item da biblioteca que está disponível para empréstimo e qual o saldo atual da biblioteca.*/
        Biblioteca daniela = new Biblioteca(0);
        daniela.mostrarSaldo();
        daniela.catalogo.add(new Livro("As cronicas do yago", 00, true, "Diniz"));
        daniela.catalogo.add(new DVD("Torneio de ping-pong", 01, true, 2));

        daniela.alugar();
        daniela.alugar();
        daniela.devolver();
        daniela.devolver();

        daniela.mostrarSaldo();
        
    }
}
