public class Livro extends Intens {
    private String autor;

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public Livro(String nome, int id, boolean disponivel, String autor) {
        super(nome, id, disponivel);
        this.setPreco(5);
        this.autor = autor;
    }

    @Override
    public String toString() {
        return super.toString()+", autor=" + autor + "]";
    }
    
    
}
