public class Caixa extends Empregado {

    public Caixa(String nome, String cpf, double saldo) {
        super(nome, cpf, saldo);
    }
    

    @Override
    public void pagarEmpregados(){
        setSaldo(getSaldo()+200);
    }
    
}
