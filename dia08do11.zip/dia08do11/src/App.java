public class App {
    public static void main(String[] args) throws Exception {
        /*A senhora Clotilde é dona do banco mais burguês da cidade. No entanto, chegou a época que ela mais temia… pagamento dos empregados.
         Existem 3 cargos diferentes ocupados por diferentes funcionários do banco. Gerente, Assistente e Caixa. Crie uma classe abstrata empregado que 
         possui atributos como: nome, cpf, saldo e um método abstrato receberSalario.
        Crie classes para cada cargo diferente do banco e faça elas herdarem de empregado. Após isso crie a classe banco que possui
         um array de empregados e um método pagarEmpregados.
        Certifique-se que o salário do gerente será maior que o do assistente e o do assistente maior que o do caixa.
         Eles podem ser números escolhidos arbitrariamente por você.*/

        Banco bradesco = new Banco();

        bradesco.empregados.add(new Gerente("Isaac", "004321123", 2000));
        bradesco.empregados.add(new Assistente("Yago", "004654798", 1000));
        bradesco.empregados.add(new Caixa("Alberto", "004653548", 750));

        bradesco.listarEmpregados();
        bradesco.pagarEmpregados();
        bradesco.listarEmpregados();

    }
}
