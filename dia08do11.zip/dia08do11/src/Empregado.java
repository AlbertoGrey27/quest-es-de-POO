public abstract class Empregado  {
    /*A senhora Clotilde é dona do banco mais burguês da cidade. No entanto, chegou a época que ela mais temia… pagamento dos empregados.
    Existem 3 cargos diferentes ocupados por diferentes funcionários do banco. Gerente, Assistente e Caixa. Crie uma classe abstrata empregado que 
    possui atributos como: nome, cpf, saldo e um método abstrato receberSalario.
    Crie classes para cada cargo diferente do banco e faça elas herdarem de empregado. Após isso crie a classe banco que possui
    um array de empregados e um método pagarEmpregados.
    Certifique-se que o salário do gerente será maior que o do assistente e o do assistente maior que o do caixa.
    Eles podem ser números escolhidos arbitrariamente por você.*/
    private String nome,cpf;
    private double saldo;

    abstract public void pagarEmpregados();

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public Empregado(String nome, String cpf, double saldo) {
        this.nome = nome;
        this.cpf = cpf;
        this.saldo = saldo;
    }

    @Override
    public String toString() {
        return "Empregado [nome=" + nome + ", cpf=" + cpf + ", saldo=" + saldo + "]";
    }
    
    
}
