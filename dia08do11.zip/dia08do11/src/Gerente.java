public class Gerente extends Empregado {

    

    public Gerente(String nome, String cpf, double saldo) {
        super(nome, cpf, saldo);
    }
    

    @Override
    public void pagarEmpregados(){
        setSaldo(getSaldo()+1000);
    }
    
}
