import java.util.ArrayList;

public class Banco {

    ArrayList<Empregado> empregados = new ArrayList<>();


    public void pagarEmpregados(){
        for (Empregado Iempregado : empregados) {
            Iempregado.pagarEmpregados();
        }
        
    }


    public void listarEmpregados(){
        for (Empregado Iempregado : empregados) {
           System.out.println(Iempregado.toString()); 
        }
    }
    
    
}
