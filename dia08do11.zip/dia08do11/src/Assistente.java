public class Assistente extends Empregado {
    public Assistente(String nome, String cpf, double saldo) {
        super(nome, cpf, saldo);
    }

    @Override
    public void pagarEmpregados(){
        setSaldo(getSaldo()+500);
    }
    
}
