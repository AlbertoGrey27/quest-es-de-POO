import java.util.Scanner;

public class App {
    /*Crie uma interface chamada Veiculo com três métodos abstratos:
    acelerar(), frear() e obterVelocidadeMaxima().

    Em seguida, crie três classes que implementam a interface Veiculo:
    Carro, Moto e Bicicleta.

    Cada classe deve fornecer uma implementação dos métodos de
    acordo com o tipo de veículo e sua funcionalidade. Crie um
    programa principal que permita ao usuário escolher um veículo,
    acelerar, frear e exibir a velocidade máxima. Use polimorfismo para
    realizar essas ações. */
    public static void main(String[] args) throws Exception {
        Carro outlander = new Carro(20, 5, 100);
        Moto yamarra = new Moto(30, 10, 120);
        Bicicleta caloi = new Bicicleta(10, 2, 50);
        Scanner sc = new  Scanner(System.in);
        String respostaDoMenu;
        for(int i = 0 ; i !=4;){
            System.out.println("escolha:\n1.Carro\n2.Moto\n3.Bicicleta\n4.Sair");
            respostaDoMenu = sc.next();
            if (respostaDoMenu=="1") {
                for(i = 0 ; i !=5;){
                    System.out.println("escolha:\n1.Acelerar\n2.Frear\n3.Checar velocidade\n4.Checar velocidade maxima\n5.Sair");
                    respostaDoMenu = sc.next();
                    if (respostaDoMenu=="1") {
                        outlander.acelerar();
                    }if (respostaDoMenu=="2") {
                        outlander.frear();
                    } if (respostaDoMenu=="3") {
                        outlander.mostrarVelocidade();
                    } if (respostaDoMenu=="4") {
                        outlander.obterVelocidadeMaxima();
                    } if (respostaDoMenu=="5") {
                        System.out.println("Parando o veiculo");
                    } else {
                        System.out.println("invalido");
                    }
                }
            }if (respostaDoMenu=="2") {
                for(i = 0 ; i !=5;){
                    System.out.println("escolha:\n1.Acelerar\n2.Frear\n3.Checar velocidade\n4.Checar velocidade maxima\n5.Sair");
                    respostaDoMenu = sc.next();
                    if (respostaDoMenu=="1") {
                        yamarra.acelerar();
                    }if (respostaDoMenu=="2") {
                        yamarra.frear();
                    } if (respostaDoMenu=="3") {
                        yamarra.mostrarVelocidade();
                    } if (respostaDoMenu=="4") {
                        yamarra.obterVelocidadeMaxima();
                    } if (respostaDoMenu=="5") {
                        System.out.println("Parando o veiculo");
                    } else {
                        System.out.println("invalido");
                    }
                }
            }if (respostaDoMenu=="3") {
                for(i = 0 ; i !=5;){
                    System.out.println("escolha:\n1.Acelerar\n2.Frear\n3.Checar velocidade\n4.Checar velocidade maxima\n5.Sair");
                    respostaDoMenu = sc.next();
                    if (respostaDoMenu=="1") {
                        caloi.acelerar();
                    }if (respostaDoMenu=="2") {
                        caloi.frear();
                    } if (respostaDoMenu=="3") {
                        caloi.mostrarVelocidade();
                    } if (respostaDoMenu=="4") {
                        caloi.obterVelocidadeMaxima();
                    } if (respostaDoMenu=="5") {
                        System.out.println("Parando o veiculo");
                    } else {
                        System.out.println("invalido");
                    }
                }
            }
            if (respostaDoMenu=="4") {
                System.out.println("fechando");
            }else{
                System.out.println("invalido");
            }
            
        }
        
    }
}
