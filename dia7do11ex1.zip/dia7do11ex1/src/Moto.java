public class Moto implements Veiculo {

    private int velocidade, aceleracao, velocidadeMaxima;

    @Override
    public void acelerar(){
        if (velocidade<velocidadeMaxima) {
            setVelocidade(getVelocidade()+getAceleracao());
        }
        if (velocidade>velocidadeMaxima) {
            setVelocidade(getVelocidadeMaxima());
        }
        
    }
    public int getVelocidadeMaxima() {
        return velocidadeMaxima;
    }
    public void setVelocidadeMaxima(int velocidadeMaxima) {
        this.velocidadeMaxima = velocidadeMaxima;
    }
    @Override
    public void frear(){
        if (velocidade>0) {
            setVelocidade(getVelocidade()-getAceleracao());
        }
        if (velocidade<0) {
            setVelocidade(0);
        }
    }
    @Override
    public void obterVelocidadeMaxima(){
        System.out.println("velocidade maxima é: "+getVelocidadeMaxima()+"km/h");
    }
    public int getVelocidade() {
        return velocidade;
    }
    
    public int getAceleracao() {
        return aceleracao;
    }
    public void setAceleracao(int aceleracao) {
        this.aceleracao = aceleracao;
    }
    public Moto(int velocidade, int aceleracao, int velocidadeMaxima) {
        this.velocidade = velocidade;
        this.aceleracao = aceleracao;
        this.velocidadeMaxima = velocidadeMaxima;
    }
    public void setVelocidade(int velocidade) {
        this.velocidade = velocidade;
    }
    public void mostrarVelocidade(){
        System.out.println(getVelocidade()+"km/h");
    }
}
