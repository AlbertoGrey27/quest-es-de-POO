public class Carro implements Veiculo {
    /*Crie uma interface chamada Veiculo com três métodos abstratos:
    acelerar(), frear() e obterVelocidadeMaxima().

    Em seguida, crie três classes que implementam a interface Veiculo:
    Carro, Moto e Bicicleta.

    Cada classe deve fornecer uma implementação dos métodos de
    acordo com o tipo de veículo e sua funcionalidade. Crie um
    programa principal que permita ao usuário escolher um veículo,
    acelerar, frear e exibir a velocidade máxima. Use polimorfismo para
    realizar essas ações. */
    private int velocidade, aceleracao, velocidadeMaxima;

    @Override
    public void acelerar(){
        if (velocidade<velocidadeMaxima) {
            setVelocidade(getVelocidade()+getAceleracao());
        }
        if (velocidade>velocidadeMaxima) {
            setVelocidade(getVelocidadeMaxima());
        }
        
    }
    public int getVelocidadeMaxima() {
        return velocidadeMaxima;
    }
    public void setVelocidadeMaxima(int velocidadeMaxima) {
        this.velocidadeMaxima = velocidadeMaxima;
    }
    @Override
    public void frear(){
        if (velocidade>0) {
            setVelocidade(getVelocidade()-getAceleracao());
        }
        if (velocidade<0) {
            setVelocidade(0);
        }
    }
    @Override
    public void obterVelocidadeMaxima(){
        System.out.println("velocidade maxima é: "+getVelocidadeMaxima()+"km/h");
    }
    public int getVelocidade() {
        return velocidade;
    }
    
    public int getAceleracao() {
        return aceleracao;
    }
    public void setAceleracao(int aceleracao) {
        this.aceleracao = aceleracao;
    }
    public Carro(int velocidade, int aceleracao, int velocidadeMaxima) {
        this.velocidade = velocidade;
        this.aceleracao = aceleracao;
        this.velocidadeMaxima = velocidadeMaxima;
    }
    public void setVelocidade(int velocidade) {
        this.velocidade = velocidade;
    }
    
    public void mostrarVelocidade(){
        System.out.println(getVelocidade()+"km/h");
    }


    
}
