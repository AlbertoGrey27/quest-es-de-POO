public interface Veiculo {
    /*Crie uma interface chamada Veiculo com três métodos abstratos:
    acelerar(), frear() e obterVelocidadeMaxima().

    Em seguida, crie três classes que implementam a interface Veiculo:
    Carro, Moto e Bicicleta.

    Cada classe deve fornecer uma implementação dos métodos de
    acordo com o tipo de veículo e sua funcionalidade. Crie um
    programa principal que permita ao usuário escolher um veículo,
    acelerar, frear e exibir a velocidade máxima. Use polimorfismo para
    realizar essas ações. */
    abstract public void acelerar();
    abstract public void frear();
    abstract public void obterVelocidadeMaxima();
    
}
