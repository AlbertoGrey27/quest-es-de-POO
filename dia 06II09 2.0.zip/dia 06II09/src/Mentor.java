public class Mentor {
    String nome;
    double experiencia;
    int numeroTelefone;
    
}
