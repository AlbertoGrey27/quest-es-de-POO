import java.util.Scanner;

public class projeto {
     Scanner sc = new Scanner(System.in);
    String data;
    String titulo;
    String descrição;

    Mentor M = new Mentor();

    aluno[] alunos = new aluno[4];

    int i = 0;
    public void metas(){
        for(i=0; i<4; i++){
            alunos[i].cumprirMetas();
        }
    }

    public void passou(){
        for(i=0; i<4; i++){
            alunos[i].Sucesso();
        }
    }

    public void mostraMetas(){
        for(i=0; i<4; i++){
            alunos[i].mostraMetas();
        }
    }



    
}
