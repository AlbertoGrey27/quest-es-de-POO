public class App {
    public static void main(String[] args) throws Exception {
        projeto proj = new projeto();

        aluno al1 = new aluno("jorge");
        aluno al2 = new aluno("Gabriel");
        aluno al3 = new aluno("Yago");
        aluno al4 = new aluno("Cadu");

        proj.alunos[0] = al1;
        proj.alunos[1] = al2;
        proj.alunos[2] = al3;
        proj.alunos[3] = al4;

        proj.metas();

        proj.passou();

        proj.mostraMetas();

    }
}
