import java.util.Scanner;
public class aluno {

    Scanner sc = new Scanner(System.in);

    String nome;
    int id;
    boolean meta[] = new boolean[5];

    

    public aluno(String nome){
        this.nome = nome;
    }

    public void cumprirMetas(){
        for(int j = 0; j<5; j++){
            System.out.print("O "+nome+" compriu a meta "+(j+1)+"(1 para sim,2 para não):");
            int input = sc.nextInt();
            if (input==1) {
                meta[j] = true;
            }else{
                meta[j] = false;
            }
        } 
    }

    public void Sucesso(){
        int cont = 0;

        for(int j = 0; j<5; j++){
            if (meta[j] == true) {
                cont++;
            }
        }
        if(cont>=3){
            System.out.println("O estudante "+nome+" passou");
        }else{
            System.out.println("O estudante "+nome+" não passou");
        }
    }

    public void mostraMetas(){
        for(int j = 0; j<5; j++){
            if (meta[j] == true) {
                System.out.println("O estudante "+nome+" compriu a meta "+(j+1));
            }else{
                System.out.println("O estudante "+nome+" não compriu a meta "+(j+1));
            }
        }
    }
    
}
