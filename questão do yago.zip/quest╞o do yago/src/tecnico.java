public class tecnico {
    String nome;
    int experiencia;

    
    
}
