public class time {
    String nome;


    torcedores Yago = new torcedores("Yago", 10 , true,"vasco");
    torcedores JoãoPaulo = new torcedores("João Paulo", 10 , true,"vasco");
    torcedores Igor = new torcedores("Igor", 5 , false,"vasco");
    torcedores Dani = new torcedores("Dani", 0 , false,"vasco");
    torcedores Jorge = new torcedores("Jorge", 0 , false,"vasco");

    tecnico paulo = new tecnico();
    public void vincular(String nome,int experiencia){
        this.nome = nome;
        this.experiencia = experiencia;
        
    }

    public time(String nome){
        this.nome = nome;
    }

    public void pagamentoTime(){
        Yago.pagamento();
        JoãoPaulo.pagamento();
        Igor.pagamento();
        Dani.pagamento();
        Jorge.pagamento();
    }

    public void print(){
        Yago.print();
        JoãoPaulo.print();
        Igor.print();
        Dani.print();
        Jorge.print();
    }


    
}
