import java.util.Scanner;

public class torcedores {

    Scanner sc = new Scanner(System.in);

    String nome;
    int presença;
    boolean socio = false;
    boolean pagamento[] = new boolean[4];
    String time;






    public torcedores(){
        
    }
    public torcedores(String nome,int presença,boolean socio, String time){
        this.nome = nome;
        this.presença = presença;
        this.socio = socio;
        this.time = time;
    }

    public void pagamento(){
        if(socio==true){
            for(int i = 0; i < 4; i++){
                System.out.println("O "+(i+1)+"º pagamento do "+nome+" foi feito(1 para sim, 2 para não): ");
                int input = sc.nextInt();
                if(input==1){
                    pagamento[i] = true;
                }
                else{
                    System.out.println("Por favor faça o pagamento");
                }
                
            }
        }
    }

    public void print(){
        System.out.println(nome);
        System.out.println("é torcedor do "+time);
        System.out.println("assistiu "+presença+" jogos");
        if (socio==true) {
            System.out.println("é socio");
            for(int i = 0; i < 4; i++){
                if(pagamento[i]== true){
                    System.out.println("o pagamento "+(1+i)+" foi feito");
                }
                else{
                    System.out.println("o pagamento "+(1+i)+" não foi feito");
                }
            }
        }
        else{
            System.out.println("não é socio");
        }
    }

    
}
