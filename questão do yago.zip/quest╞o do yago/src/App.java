public class App {
    public static void main(String[] args) throws Exception {
        

        time vascoTime = new time("Vasco");

        vascoTime.pagamentoTime();

        vascoTime.print();


    }
}
